﻿using System.Threading.Tasks;

namespace MyHttpServer.Services
{
    public interface IMailService
    {
        public static void SendAsync()
        {
        	
        }
    }
}
